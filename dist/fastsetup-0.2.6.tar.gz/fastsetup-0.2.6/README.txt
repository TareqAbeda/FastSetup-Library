A Python library that has all the static repetitive code used in Python scripts, for easier and faster setup.

Development Status :: Planning
